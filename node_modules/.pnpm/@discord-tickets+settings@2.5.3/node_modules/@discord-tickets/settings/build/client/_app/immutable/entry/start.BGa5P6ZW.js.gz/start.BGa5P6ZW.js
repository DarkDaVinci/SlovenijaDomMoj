import{a as t}from"../chunks/CqbrNuPL.js";export{t as start};
